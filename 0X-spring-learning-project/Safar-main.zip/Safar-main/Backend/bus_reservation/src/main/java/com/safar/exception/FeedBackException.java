package com.safar.exception;

public class FeedBackException extends Exception{
	
	
public FeedBackException() {
	// TODO Auto-generated constructor stub
}
	

public FeedBackException(String msg) {
	super(msg);
	// TODO Auto-generated constructor stub
}

}
