package com.safar.exception;

public class ReservationException extends Exception{
    public ReservationException(){}

    public ReservationException(String message){
        super(message);
    }
}
